# - Magyka - # - By Vincent G, aka Mutater - #

To play Magyka, open "run.bat"